VIBE CODE JAM 2026 - SAP DATASET
================================

All people, IDs, grades and records are invented. Programs and courses are real (ZU Catalog 2025-2026).
Today in this dataset: Wednesday 18 November 2026. Current term: 202610 (2026 Fall Semester).

FILES
  SAP_Data.xlsx  Open in Excel to explore. First sheet explains every table and how they connect.
  data/core/      14 tables the 7 core features need. Start with these.
  data/extras/    score_records, exam_schedule, entry_logs, news, courses_full (with descriptions).

TIP
  Ask your AI tool to build the app so it LOADS the CSV files when it starts.
  If it copies the data into the code, it will cut rows or invent data, and the jury will notice.

TEST LOGINS (student_id / password)
  Every student in students.csv can log in. The jury will use these and others:
  202312001 / Zu@2001    Shaikha Al Mansoori, BSIT-WMAD, semester 7
  202412002 / Zu@2002    Omar Al Hameli, BSACC, semester 5
  202512003 / Zu@2003    Dana Al Nuaimi, BSCMS-MPS, semester 3
  202412004 / Zu@2004    Reem Al Ali, BSPSY, semester 5
  202305005 / Zu@5005    Khalid Al Hameli, BSPSY, semester 8
  202412006 / Zu@2006    Sara Al Ali, BFAGD, semester 5
  202612007 / Zu@2007    Ahmed Al Zaabi, BSIT-WMAD, semester 1
  202312008 / Zu@2008    Moza Al Rumaithi, BSACC, semester 7

  Make sure every screen works for every student, not just one.
